export const ADD_TO_CART="ADD_TO_CART";
export const REMOVE_TO_CART="REMOVE_TO_CART";
export const EMPTY_TO_CART="EMPTYTO_CART";
export const DeliveryAddress="Delivery_Address";

export const LOGIN_USER1="LOGIN_USER";
export const ZipCode="Zip_Code";
export const areaProduct="Area_Product";
export const delivery_time="Deliverytime";



export const LOADING = 'LOADING'
export const ERROR = 'ERROR'
export const SET_LANGUAGE = 'SET_LANGUAGE'