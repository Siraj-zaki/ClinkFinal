import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import "./css/index.css"

import  App  from './app'

// import Home from './components/Home';
ReactDOM.render(


    <App />

    
    ,
    document.getElementById('root'));